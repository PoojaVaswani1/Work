package com.Online.BookStore.service;

import java.util.List;
import java.util.Map;

import org.springframework.data.crossstore.ChangeSetPersister.NotFoundException;

import com.Online.BookStore.model.Books;


public interface BooksService {
	
	
	public Books saveBooks(Books books);
	public List<Books> getAllBooks();
	public Books findByTitle(String title) throws NotFoundException;
	public List<Books> findByAuthor(String author);
	//public Map<Books, Integer> addToCart(List<Books> selectedBooks);
	//boolean check(List<String> bookTitles);
	
}
