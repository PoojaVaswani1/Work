package com.Online.BookStore.service;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.crossstore.ChangeSetPersister.NotFoundException;
import org.springframework.stereotype.Service;

import com.Online.BookStore.model.Books;
import com.Online.BookStore.repo.BooksRepo;

@Service
public class BooksserviceImpl implements BooksService{
	@Autowired
	public BooksRepo booksRepo;

	@Override
	public Books saveBooks(Books books) {
		// TODO Auto-generated method stub
		return booksRepo.save(books);
	}

	@Override
	public List<Books> getAllBooks() {
		// TODO Auto-generated method stub
		return booksRepo.findAll();
	}

	@Override
	public Books findByTitle(String title) throws NotFoundException {
	    Optional<Books> optionalBooks = Optional.of(booksRepo.getByTitle(title));
	    
	    if (optionalBooks.isPresent()) {
	        return optionalBooks.get();
	    } else {
	        // Handle the case when the title is not found, e.g., throw an exception or return a default value
	        throw new NotFoundException();
	    }
	
	
	
}

	@Override
	public List<Books> findByAuthor(String author) {
		// TODO Auto-generated method stub
		return booksRepo.findByAuthor(author);
	}

	

	
}
