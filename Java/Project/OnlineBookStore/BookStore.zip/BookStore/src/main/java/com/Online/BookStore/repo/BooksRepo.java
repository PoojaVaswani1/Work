package com.Online.BookStore.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Online.BookStore.model.Books;


public interface BooksRepo extends JpaRepository<Books, Long>{
	Books getByTitle(String title);

	List<Books> findByAuthor(String author);

}