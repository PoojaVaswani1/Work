package com.Online.BookStore.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.crossstore.ChangeSetPersister.NotFoundException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.Online.BookStore.model.Books;
import com.Online.BookStore.service.BooksService;


@RestController
public class BooksController {
	@Autowired
	private BooksService booksService;
	
	@PostMapping("/saveBooks")
	public ResponseEntity<?> saveBoks(@RequestBody Books books){
		return new ResponseEntity<> (booksService.saveBooks(books),HttpStatus.CREATED);
	}
	
	@GetMapping("/books")
	public ResponseEntity<?> getAllBooks(){
		return new ResponseEntity<> (booksService.getAllBooks(),HttpStatus.OK);

}
	 @GetMapping("/tittle/{title}")
	    public ResponseEntity<?> findByTitle(@PathVariable String title) throws NotFoundException {
	        return new ResponseEntity<>(booksService.findByTitle(title), HttpStatus.OK);
	    }
	 
	 @GetMapping("/author/{author}")
	 public ResponseEntity<?> findByAuthor(@PathVariable String author){
		 return new ResponseEntity<> (booksService.findByAuthor(author), HttpStatus.OK);
	 }
	 
	 
}