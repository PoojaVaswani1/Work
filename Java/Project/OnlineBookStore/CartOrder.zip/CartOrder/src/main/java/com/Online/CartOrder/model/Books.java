package com.Online.CartOrder.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Books {
	private long id;
	private String author;
	private String title;
	private String isbn;
	private int price;
	private int  availabilty;
	

}
