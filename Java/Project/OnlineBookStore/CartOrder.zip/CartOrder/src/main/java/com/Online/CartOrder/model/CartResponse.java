package com.Online.CartOrder.model;

import java.util.List;



import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CartResponse {

    private Long userId;
    private Long cartId;
    private Integer totalItems;
    private Double totalCost;
    private List<Books> allBooks;

    
}
