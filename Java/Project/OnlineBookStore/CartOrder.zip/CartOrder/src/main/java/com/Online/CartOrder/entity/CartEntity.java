package com.Online.CartOrder.entity;



import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CartEntity {

    private Long userId;
    private Long cartId;
    private Integer totalItems;
    private Double totalCost;
    private String allBooks;

    

}

