package com.Online.CartOrder.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.crossstore.ChangeSetPersister.NotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;


import com.Online.BookStore.service.BooksService;
import com.Online.CartOrder.entity.CartEntity;
import com.Online.CartOrder.model.Books;
import com.Online.CartOrder.model.CartRequest;
import com.Online.CartOrder.model.CartResponse;
import com.Online.CartOrder.repo.CartRepo;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;


@Service
public class CartService {
	@Autowired
	@Qualifier("webclient")
	private WebClient.Builder webBuilder;
	//reqBookList.stream().map(e -> String.valueOf(e.getProductId())).collect(Collectors.joining(","));
	@Autowired
	private CartRepo cartRepository;

		public CartResponse processAddRequest(Long userId, List<CartRequest> reqBookList) {
			ObjectMapper mapper = new ObjectMapper();
	        String bookServiceUrl = "http://book-service/books/" + reqBookList.stream().map(e -> String.valueOf(e.getId())).collect(Collectors.joining(","));
			List<Books> bookServiceList = webBuilder.build()
					.get()
					.uri(bookServiceUrl)
					.retrieve()
					.bodyToFlux(Books.class)
					.collectList()
					.block();
			
			System.out.println(bookServiceUrl);
			System.out.println(bookServiceList);
			
			//calculate total cost
			final  Double[] totalCost = {0.0};
			bookServiceList.forEach(bsl->{
				reqBookList.forEach(rbl->{
					if(bsl.getId()==rbl.getId()) {
						bsl.setAvailabilty(rbl.getAvailabilty());
						totalCost[0] = totalCost[0] + bsl.getPrice()* rbl.getAvailabilty();
					}
				});
			});
			
			
			//create cart entity
			CartEntity cartEntity=null;
			try {
			 cartEntity = CartEntity.builder()
					.userId(userId)
					.cartId((long)(Math.random()*Math.pow(10,10)))
					.totalItems(bookServiceList.size())
					.totalCost(totalCost[0])
					.allBooks(mapper.writeValueAsString(bookServiceList))
					.build();
					
		}catch(JsonProcessingException e) {
			throw new RuntimeException(e);	}
			
			
			//save cart entity
			cartEntity = cartRepository.save(cartEntity);
			
			
			//create api response
			CartResponse response = CartResponse.builder()
					.cartId(cartEntity.getCartId())
					.userId(cartEntity.getUserId())
					.totalItems(cartEntity.getTotalItems())
					.totalCost(cartEntity.getTotalCost())
					.allBooks(bookServiceList)
					.build();
			return response;
		}

		}

		// Inject BooksService for searching by title

		