package com.Online.CartOrder.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Online.CartOrder.entity.CartEntity;


public interface CartRepo extends JpaRepository<CartEntity, Long> {
	List<CartEntity> findByUserId(Long userId);

}
