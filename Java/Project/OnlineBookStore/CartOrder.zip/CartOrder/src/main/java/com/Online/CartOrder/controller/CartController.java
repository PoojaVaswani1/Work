package com.Online.CartOrder.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Online.CartOrder.model.CartRequest;
import com.Online.CartOrder.model.CartResponse;
import com.Online.CartOrder.service.CartService;



@RestController
@RequestMapping("/cart")
public class CartController {

    @Autowired
    private CartService cartService;

    // Add a book to the cart
    @PostMapping("/{userId}/books")
    public ResponseEntity  addBooksToCart(@PathVariable Long userId,
			@RequestBody List<CartRequest> reqBookList) {
    	CartResponse response = cartService.processAddRequest(userId,reqBookList);
    	return new ResponseEntity(response,HttpStatus.CREATED);
    	
    }
    
   
        
    
}

